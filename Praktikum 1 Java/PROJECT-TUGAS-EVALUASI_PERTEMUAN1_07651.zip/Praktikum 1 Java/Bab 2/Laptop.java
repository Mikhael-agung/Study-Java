public class laptopMain {
    
}
